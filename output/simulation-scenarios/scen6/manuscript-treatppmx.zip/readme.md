#README

This folder contains the files for the manuscript for
Bayesian Nonparametric Predictive Model for Personalized Treatment Selection in Cancer Genomics
by M. Pedone, R. Argiento & F.C. Stingo

It consists of the following files:

* readme.txt        this file
* draft_ppmx.tex    the work in progress paper
* biblio.bib        bibtex references file
